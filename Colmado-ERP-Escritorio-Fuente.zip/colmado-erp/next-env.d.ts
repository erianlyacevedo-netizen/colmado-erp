/// <reference types="next" />
/// <reference types="next/image-types/global" />
// Este archivo se administra automáticamente por Next.js.
